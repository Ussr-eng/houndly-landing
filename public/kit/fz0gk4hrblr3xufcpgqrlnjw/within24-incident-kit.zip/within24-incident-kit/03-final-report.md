# 03 · Final report

**Deadline:**
- **Actively exploited vulnerability:** no later than **14 days after a corrective or mitigating measure is available** (Art. 14(2)(c)).
- **Severe incident:** within **one month after the 72h notification** (Art. 14(4)(c)).

**Goal:** close the loop. What happened, how bad it was, why, and what has been done so it does not happen again.

> **Once submitted, the notification can no longer be edited on the SRP.** Read it twice.

> Vulnerability: the 14 days start when the *fix or mitigation is available*, not when the incident started. The SRP has no counter for this one. Put it in your calendar the day you ship the fix.

---

## Final report: actively exploited vulnerability

### 1. Description of the vulnerability, including its severity and impact
**Hint:** Now you can be complete: affected versions (final), root cause in plain terms, CWE, CVSS (final), CVE/EUVD ID, how many devices or users were affected in the end.
**Example:** Authentication bypass in the ExampleHub R200 web administration interface (CWE-287, CVE-2026-XXXXX, CVSS 3.1 8.8). Firmware 3.0.0 – 3.4.2 are affected. A missing session check on one configuration endpoint allowed unauthenticated changes. 41 devices at 4 customers were confirmed compromised; attackers changed DNS settings to redirect traffic.

**Yours:**
```

```

### 2. Information about the malicious actor *(where available)*
**Hint:** What you know about who exploited it and how: infrastructure, behaviour, indicators. Say where it comes from (your logs, threat intel, law enforcement). "No information available" is acceptable.
**Example:** Exploitation came from a small set of hosting IP ranges consistent with an automated botnet. Indicators shared with the CSIRT separately. No attribution.

**Yours:**
```

```

### 3. Security update or other corrective measures
**Hint:** What you released, when, how it reaches users (automatic or manual), uptake so far, and any measures beyond the patch (hardening, process changes).
**Example:** Firmware 3.4.3 released 21 Oct 2026 via automatic update; 78% of active devices updated by 30 Oct 2026. Remote administration now off by default. Added authentication tests for all admin endpoints to CI.

**Yours:**
```

```

### 4. Date the corrective measure became available
**Example:** 2026-10-21

**Yours:** ______________________

---

## Final report: severe incident

### 1. Detailed description, including severity and impact
**Hint:** Full timeline (start, detection, containment, recovery), which products and versions were affected, how many users, which security properties were hit (availability, authenticity, integrity, confidentiality), and the actual effect on users.
**Example:** Between 12 and 14 Oct 2026 an attacker used a stolen CI credential to access a build server and caused a modified firmware image (3.4.2-b) to be signed and published. The image was available for 6 h 12 min and installed on 1,900 devices. The modification added a remote shell. Integrity and confidentiality of affected devices were compromised. No evidence of further activity after 14 Oct 2026.

**Yours:**
```

```

### 2. Type of threat or root cause that likely triggered the incident
**Hint:** The root cause, not just the trigger. "Phishing" is a trigger; "CI credential with signing rights stored in plain text, no MFA" is the root cause.
**Example:** Long-lived CI token with access to the signing service was leaked from a developer workstation. The signing service did not require a second approval for production releases.

**Yours:**
```

```

### 3. Applied and ongoing mitigation measures
**Hint:** Split into *done* and *in progress*, with dates.
**Example:** Done: rogue image withdrawn (14 Oct); clean firmware 3.4.3 forcibly pushed (15 Oct); all CI credentials rotated; signing key rotated. In progress: hardware-backed signing with two-person approval (target Dec 2026); external audit of build pipeline (Nov 2026).

**Yours:**
```

```

---

## Before you press Submit

- [ ] All facts match the latest update of the notification (or are explicitly corrected).
- [ ] Final numbers, not estimates, wherever you have them.
- [ ] Users have been informed (Art. 14(8)), and the advisory is published.
- [ ] A second person read it.
- [ ] Copy and SRP reference saved. Incident folder archived with the timeline.
- [ ] Post-incident review booked: what would have made the first 24 hours easier?
