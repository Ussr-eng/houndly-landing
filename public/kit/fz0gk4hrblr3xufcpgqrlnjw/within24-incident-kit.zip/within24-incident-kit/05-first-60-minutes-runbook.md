# 05 · Runbook: the first 60 minutes after a signal

**Print this.** It is written for the person who gets the signal, at any hour, who may not be a security expert.

A *signal* is anything that suggests a product you ship is being attacked or abused: a customer report, a researcher email, a monitoring alert, a news article, a message from a CSIRT, odd behaviour in your update or build systems.

The CRA clock (24h → 72h → final) starts when you have **reliable information**, not when someone first worried. Your job in the first hour is to get to that answer fast, write everything down, and make sure the right people are awake.

---

## Minute 0–5 · Start the record

- [ ] Note the time **in UTC** and what arrived, from whom, through which channel.
- [ ] Open an incident folder from the templates (copy, don't edit the masters).
- [ ] Start the timeline below. Every action, every decision, with a time.
- [ ] **Do not** delete, reboot, reimage, or "clean up" anything yet. Preserve logs and evidence.
- [ ] **Do not** discuss details in public channels, public tickets, or with the reporter beyond acknowledging receipt.

## Minute 5–15 · Wake the right people

- [ ] Call (don't just message) the **on-call security lead**. If no answer in 10 minutes, call the backup. Then the next one.
- [ ] Notify the **Assigned Representative** for the SRP (Primary or Secondary) that a report may be needed today.
- [ ] Open one private channel or call for this incident. Name it with a date, not with the product or bug.
- [ ] Assign two roles out loud: **Incident lead** (decides) and **Scribe** (keeps the timeline). Can be the same person if you are two.

## Minute 15–40 · Triage: is it reportable?

Answer these, writing down the evidence for each answer.

**1. Is it our product?**
- Which product, which versions? Is the affected component ours or a third-party/open-source component in our product? (If it is a component, it is still reportable for *your* product if the conditions below are met. Also tell the component's maintainer, CRA Art. 13(6).)

**2. Is a vulnerability being actively exploited?**
- Is there **reliable evidence** that a malicious actor has exploited it in someone's system without permission? (Logs, a customer's forensic finding, a CSIRT or vendor advisory saying "exploited in the wild".)
- A theoretical issue, a researcher's report, or a public PoC alone usually is **not** "actively exploited". Keep it on your normal vulnerability handling track, and re-check if evidence appears.

**3. Is it a severe incident affecting the security of the product?** It is severe if either:
- it negatively affects, or could affect, the product's ability to protect the **availability, authenticity, integrity or confidentiality** of sensitive or important data or functions; **or**
- it has led, or could lead, to **malicious code** being introduced or executed in the product or in users' systems.
- Typical examples: compromised build or update pipeline, stolen signing keys, a malicious update shipped to users.

**4. Other clocks?**
- Personal data involved? GDPR breach notification, 72 hours, data protection authority.
- Are *you* also an essential/important entity under NIS2? Separate report to your NIS2 authority (24h early warning).
- Sector rules (finance/DORA, health, energy, etc.)?

**Decision:**
- [ ] **Reportable** → write down the *time of awareness* and the reason. This is T0 for the CRA clocks.
- [ ] **Not reportable (yet)** → write down why, what would change your mind, and when you will look again.
- [ ] **Unsure** → treat as reportable for planning. Set T0 now. You can stand down later.

## Minute 40–55 · Set the clocks and start the drafts

- [ ] Calculate and put in the shared calendar, with alarms:
  - Early warning due: **T0 + 24h** = ______________ UTC
  - Notification due: **T0 + 72h** = ______________ UTC
  - Final report: set later (14 days after the fix / 1 month after the notification).
  - Any other regime's deadlines: ______________
- [ ] Owner for the early warning: ______________ (must be a registered AR, or have one ready to submit).
- [ ] Start filling `01-early-warning-24h.md` now, while facts are fresh. Most fields can be done in 20 minutes.
- [ ] First containment steps that do not destroy evidence (e.g., disable an exposed feature remotely, pause the update server, revoke a leaked credential). Log each one.

## Minute 55–60 · Handover

- [ ] Write a 5-line status: what we know, what we don't, what's next, who owns what, next check-in time.
- [ ] Agree the next check-in (e.g. every 2 hours overnight).
- [ ] If the incident lead is going to sleep, hand over explicitly, with the timeline, to a named person.

---

## Timeline (copy into the incident folder)

| Time (UTC) | Who | What happened / what we did / what we decided | Evidence |
|---|---|---|---|
| | | Signal received | |
| | | | |
| | | | |
| | | Time of awareness (T0) set because: | |
| | | Early warning submitted, SRP ref: | |

## Contacts (fill in before you need it)

| Role | Name | Phone | Backup |
|---|---|---|---|
| On-call security lead | | | |
| Primary AR (SRP) | | | |
| Secondary AR (SRP) | | | |
| Product/engineering lead | | | |
| Legal / DPO | | | |
| Communications / support lead | | | |
| Coordinating CSIRT | | | |

---

*Within24 does this part for you: wakes the person on duty, escalates if no one answers, starts all the clocks, and has the early warning draft ready. within24.app*
