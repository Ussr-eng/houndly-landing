# 02 · Notification (72 hours)

**Deadline:** without undue delay, and in any case **within 72 hours of becoming aware** (not 72 hours after the early warning).
**Legal basis:** CRA Art. 14(2)(b) (vulnerability) / Art. 14(4)(b) (severe incident).
**Goal:** give the authorities a first picture: what it is, how bad it looks, and what you and your users are doing about it.

On the SRP you **update the same notification** you opened with the early warning. Everything from template 01 stays; this adds to it. Correct anything from the early warning that turned out wrong, and say so.

---

## Fields

### 1. General information
**What to write:**
- *Vulnerability:* general information about the product, the **general nature of the exploit** and of the vulnerability.
- *Incident:* the **nature of the incident**, when it started, when it was detected.

**Hint:** Describe the class of problem, not a recipe. "Authentication bypass via crafted HTTP request to the admin interface" is right. A request payload is wrong.
**Example (vulnerability):** ExampleHub R200 is a consumer and small-office router. The vulnerability is an authentication bypass in the web administration interface (CWE-287). An unauthenticated attacker with network access to the interface can change device configuration. Exploitation has been observed against devices whose admin interface is exposed to the internet.
**Example (incident):** On 12 Oct 2026 an attacker obtained access to a build server through a compromised CI credential. On 14 Oct 2026 we detected that a modified firmware image (3.4.2-b) was signed and published on our update server for approx. 6 hours.

**Yours:**
```

```

### 2. Initial assessment
**What to write:** How severe you think it is, how many users or devices could be affected, how it is being exploited (targeted vs. mass), what is still unknown.
**Hint:** Give numbers with ranges and say where they come from. "~4,000 devices with internet-exposed admin interface, based on our telemetry" beats "many".
**Example:** We assess severity as high (CVSS 3.1 base 8.8, provisional). Telemetry indicates ~4,000 of ~120,000 active devices have the admin interface exposed to the internet. We have confirmed exploitation on 37 devices belonging to 3 customers. Exploitation appears opportunistic (internet scanning). The full affected version range is still being confirmed.

**Yours:**
```

```

### 3. Corrective or mitigating measures taken
**What to write:** What *you* have done so far and what is planned, with dates.
**Hint:** Include planned dates for a fix even if provisional. "Fix expected by 21 Oct 2026" lets the CSIRT plan.
**Example:** Remote admin access disabled by default via cloud configuration push on 15 Oct 2026 for managed devices. Firmware 3.4.3 with a fix is in testing; release planned for 21 Oct 2026. CVE requested.

**Yours:**
```

```

### 4. Measures users can take
**What to write:** Concrete steps users can take *now*, before a fix.
**Hint:** Write this as if for a non-expert admin. This text will be reused in your user notification (Art. 14(8)), so get it right once.
**Example:** Disable remote administration (Settings → Remote access → Off). If remote access is required, restrict it to known IP addresses. Change the admin password after disabling. Install firmware 3.4.3 as soon as it is available.

**Yours:**
```

```

### 5. Sensitivity of the information
**What to write:** How sensitive you consider what you have reported, and why. Whether you see reasons the CSIRT should delay sharing it further.
**Hint:** This is where you protect details, instead of omitting them. Under Art. 16(2), in particularly exceptional circumstances you can ask the CSIRT to delay dissemination (for example, if no fix exists and wider sharing would lead to mass exploitation). If you mark this, ENISA initially receives only part of the notification. Use it when it is justified, and explain why.
**Example:** High. No fix is available yet and the vulnerability is trivial to exploit. We ask that technical details are not shared beyond the coordinating CSIRT and ENISA until firmware 3.4.3 is released (planned 21 Oct 2026).

**Yours:**
```

```

---

## Before you press Submit

- [ ] Submitted **before awareness time + 72 h**.
- [ ] Anything in the early warning that changed is corrected, and the change is explained.
- [ ] "Measures users can take" is also going out to users (see below).
- [ ] Copy and SRP reference saved in the incident folder.
- [ ] Final report deadline noted:
  - vulnerability: **date the fix or mitigation becomes available + 14 days** (the SRP has no counter for this one);
  - incident: **date of this notification + 1 month**.

## Don't forget: inform your users

Art. 14(8): after becoming aware, inform impacted users (and, where appropriate, all users) about the vulnerability or incident and any risk-mitigation and corrective measures they can take. Where appropriate, in a structured, machine-readable format that is easy to process automatically (for example a CSAF advisory). The SRP report does not do this for you. If you do not inform users in time, the CSIRT may do it.

## Interim reports

The coordinating CSIRT can ask you for an interim report on relevant status updates (Art. 14). On the SRP you can update a notification until the final report is submitted; every update is passed on to the CSIRT and ENISA automatically. After the final report, the notification can no longer be edited.
