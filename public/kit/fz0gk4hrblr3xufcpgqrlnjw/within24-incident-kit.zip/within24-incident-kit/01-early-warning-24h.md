# 01 · Early warning (24 hours)

**Deadline:** without undue delay, and in any case **within 24 hours of becoming aware**.
**Legal basis:** CRA Art. 14(2)(a) (vulnerability) / Art. 14(4)(a) (severe incident).
**Goal:** tell the authorities *that* something is happening. Not *what exactly* or *why*. That comes later.

> If you are unsure whether it qualifies, and the 24 hours are running out, the safer move is usually to submit. An early warning that turns out to be minor costs you an update. A missed deadline costs a lot more.

---

## Before you open the form

- [ ] Who is submitting? Must be a registered Assigned Representative (see `04-srp-readiness-checklist.md`).
- [ ] Which category? **Actively exploited vulnerability** or **severe incident**. If both apply, they are separate notifications.
- [ ] What is your time of awareness? Write it down in UTC. Your 24h and 72h clocks run from here.

---

## Fields

### 1. Notification type
**What to write:** "Actively exploited vulnerability" or "Severe incident having an impact on the security of the product".
**Hint:** Actively exploited = there is *reliable evidence* that a malicious actor has exploited it in a system without the owner's permission (Art. 3(42)). A proof-of-concept on GitHub is not, by itself, active exploitation. A customer's logs showing it used against them is.
**Example:** Actively exploited vulnerability

**Yours:** ______________________

### 2. Title
**What to write:** One line. Product + type of problem. No exploit details.
**Hint:** The CSIRT reads dozens of these. Make it searchable.
**Example:** Authentication bypass in ExampleHub router web interface, exploited in the wild

**Yours:** ______________________

### 3. Summary
**What to write:** 2–4 sentences. What you observed, how you learned about it, what you are doing now.
**Hint:** Facts only. Say what is confirmed and what is suspected. No root-cause speculation.
**Example:** On 14 Oct 2026 at 21:10 UTC a customer reported unauthorised configuration changes on two ExampleHub devices. Log review confirms exploitation of a previously unknown authentication bypass in the admin web interface. Investigation and development of a fix are under way.

**Yours:**
```

```

### 4. Manufacturer
**What to write:** Legal entity name, as registered on the SRP. Country of main establishment.
**Hint:** Must match the manufacturer your Assigned Representative is associated with.
**Example:** ExampleCo GmbH, Germany

**Yours:** ______________________

### 5. Affected product
**What to write:** Product name as sold, and the affected version(s) or range.
**Hint:** If you do not know the full range yet, give what you know and write "range under investigation".
**Example:** ExampleHub R200 router, firmware 3.1.0 – 3.4.2 (earlier versions under investigation)

**Product:** ______________________
**Version(s):** ______________________

### 6. Date and time of awareness
**What to write:** When you had *reliable information* that this is an actively exploited vulnerability or a severe incident. UTC.
**Hint:** Not when the first alert fired, and not when the meeting ended. Document *why* this is the moment (in your timeline). The authority may ask.
**Example:** 2026-10-14 22:05 UTC (log review confirmed exploitation)

**Yours:** ______________________

### 7. Member States where the product is made available *(if known)*
**What to write:** EU countries where the product is sold or distributed.
**Hint:** Your sales or distribution data. "All EU Member States" is a valid answer for online distribution.
**Example:** DE, AT, NL, PL

**Yours:** ______________________

### 8. *Severe incidents only:* suspected unlawful or malicious acts
**What to write:** Yes / No / Unknown, plus one sentence why.
**Hint:** Required for incidents. A misconfiguration or outage with no attacker is "No". An intrusion is "Yes".
**Example:** Yes. Unauthorised access to the update signing infrastructure is suspected.

**Yours:** ______________________

### 9. Optional, if known
| Field | Example | Yours |
|---|---|---|
| Affected component | `webadmin` module | |
| CVE ID | CVE-2026-XXXXX (requested) | |
| EUVD ID | | |
| Attack vector | Network, unauthenticated | |

---

## Before you press Submit

- [ ] A second person read it.
- [ ] No exploit details, credentials, internal IPs, or customer names in free text.
- [ ] Time of awareness recorded in your incident timeline, with the reason.
- [ ] Saved a copy (PDF/screenshot) and the SRP reference number in the incident folder.
- [ ] 72h deadline put in the calendar: **awareness time + 72 h**.

> **Watch out:** at launch the SRP showed the 72h due date as *48 hours after you submit the early warning*, not 72 hours after awareness. If you submit the early warning early, the platform's date will be earlier than the legal one. ENISA said this will change. Plan to the earlier of the two dates.
