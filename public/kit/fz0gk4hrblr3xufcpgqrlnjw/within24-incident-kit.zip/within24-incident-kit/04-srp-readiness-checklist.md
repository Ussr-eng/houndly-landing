# 04 · ENISA SRP readiness checklist

Do this **now**, on a quiet day. Every item here is something you do not want to discover at 3 a.m. on a Sunday.

Portal: **portal.cra-srp.enisa.europa.eu** · Accounts: EU Login with multi-factor authentication · Language: English · Submission: web form only, no API.

Time needed: about 1–2 hours of work, plus waiting for your CSIRT to verify your association.

---

## A. Decide who and where

- [ ] **We are a manufacturer under the CRA** for at least one product with digital elements made available in the EU. (Importers, distributors and others do not report through the SRP under Art. 14; they contact the national CSIRT.)
- [ ] **We know our coordinating CSIRT.** It is the CSIRT of the Member State of our *main establishment* in the EU: where decisions on product cybersecurity are mainly taken (if unclear, where we have the most employees). No EU establishment? The cascade in Art. 14(7): authorised representative → importer → distributor → Member State with most users. Picking the wrong CSIRT can get the notification invalidated.
  - Our CSIRT: ______________________
- [ ] **We have chosen the Primary Assigned Representative** (the person who registers us and invites others). It is a role, not a job title: someone who understands the products, can reach the product team fast, and can answer CSIRT questions.
  - Primary AR: ______________________
- [ ] **We have at least one Secondary AR** (backup, ideally in a different time zone or on a different holiday schedule). The SRP allows up to 20.
  - Secondary AR(s): ______________________
- [ ] **We know who decides "this is reportable".** Usually: someone who can judge *actively exploited* / *severe* technically, plus someone with authority to submit. Write both names down, and who replaces each.
  - Decides on technical classification: ______________ (backup ______________)
  - Authorises submission: ______________ (backup ______________)

## B. Accounts and access

- [ ] Every AR has a **personal** EU Login account (accounts must not be shared). Use the work email.
- [ ] Every AR has set up **multi-factor authentication** (EU Login app on a phone, or another method EU Login supports).
- [ ] MFA works on a **second device** too, or there is a documented recovery path. (One EU Login account can be linked to several phones.)
- [ ] Primary AR has **registered** on the SRP: chose the role, selected the CSIRT, logged in, accepted terms, entered manufacturer details.
- [ ] **Association verified** by the CSIRT (check under Settings → Association Management). Verification time varies by CSIRT. Until it is verified you cannot invite Secondary ARs, so start early.
- [ ] Secondary ARs **invited and onboarded** through the invitation function (not by registering separately).
- [ ] Each AR has **logged in once** and seen the form. Not just "has an account".

> Good to know: drafts on the SRP are visible only to the person who created them, and a Secondary AR sees only the notifications they submitted themselves. Agree who submits what, and keep your own copy of every text outside the platform.

## C. Information you will need in a hurry

Keep this in one place that every AR can open without VPN or office access.

- [ ] Exact manufacturer legal name and main establishment, as registered.
- [ ] **Product list** with names as sold and current/supported versions.
- [ ] **Where each product is sold** (EU Member States). Sales or distribution can usually export this.
- [ ] Ways to reach **all users** of each product quickly (email list, in-app message, update channel, status page, advisory page).
- [ ] **SBOM** for each product, so you can tell within minutes whether a vulnerable component is in it.
- [ ] Contact for **CVE requests** (your CNA, or another CNA) and, if relevant, for EUVD.
- [ ] Your coordinating CSIRT's **contact details and guidance**, including what to do if the SRP itself is down. *(Guidance differs: BSI accepts email to CERT-Bund only during an SRP outage; other sources say to wait and submit on the SRP when it is back. Check what your CSIRT says, and write it down here.)*
- [ ] Contacts for **other regimes** that may apply to the same event: NIS2 authority, data protection authority (GDPR, 72 hours), sector regulators. One event can start several clocks.

## D. Process

- [ ] Templates from this kit copied to a shared, access-controlled location.
- [ ] The runbook (`05-first-60-minutes-runbook.md`) printed or saved offline for each person on call.
- [ ] Security intake works out of hours: a security contact on the website (e.g. `security.txt`), a monitored address, and a way to wake a human.
- [ ] There is an on-call rota that covers weekends and holidays, with names, not "the team".
- [ ] Customer support knows the phrases that should go straight to security ("someone changed my settings", "your update looks weird", a researcher email).
- [ ] Rule agreed: **when in doubt near the 24h mark, submit the early warning** and correct it later.

## E. Test it

- [ ] **Tabletop exercise** (30–45 min): take a realistic scenario, run the runbook, fill in templates 01 and 02 with a timer running. Do not submit on the live SRP (it accepts only real mandatory notifications).
- [ ] Measured: how long from "signal" to "early warning ready to submit"? Target: well under 24 hours, including a night or weekend.
- [ ] Repeat every 6 months, and whenever an AR changes.

---

**Signed off by:** ______________________ **Date:** ______________

**Next review:** ______________
