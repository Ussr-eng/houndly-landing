# Within24 Incident Kit

**CRA reporting, ready before you need it.**
Version 1.0 · October 2026 · [within24.app](https://within24.app)

Since **11 September 2026**, Article 14 of the EU Cyber Resilience Act (Regulation (EU) 2024/2847) requires manufacturers of products with digital elements sold in the EU to report **actively exploited vulnerabilities** and **severe incidents** through ENISA's Single Reporting Platform (SRP). The clock starts when you become aware, not when you are ready.

This kit is what we would want on the shelf the night a signal arrives.

## What's inside

| File | Use it when |
|---|---|
| `01-early-warning-24h.md` | Within 24 hours of becoming aware |
| `02-notification-72h.md` | Within 72 hours of becoming aware |
| `03-final-report.md` | 14 days after a fix (vulnerability) or 1 month after the 72h notification (incident) |
| `04-srp-readiness-checklist.md` | **Today.** Before anything happens |
| `05-first-60-minutes-runbook.md` | The moment a signal arrives. Print it |

Every template mirrors the order of the SRP web form, so you can copy field by field. Each field has a short hint (what the authority needs), a fictional example, and a blank to fill in.

## The three clocks at a glance

| Stage | Actively exploited vulnerability | Severe incident |
|---|---|---|
| Early warning | 24 h after becoming aware | 24 h after becoming aware |
| Notification | 72 h after becoming aware | 72 h after becoming aware |
| Final report | ≤ 14 days after a corrective or mitigating measure is available | ≤ 1 month after the 72h notification |

All stages go to the CSIRT designated as coordinator and to ENISA **at the same time**, through one submission on the SRP. Reports are written in English.

Separately from the SRP, you must also **inform impacted users** about the vulnerability or incident and what they can do (Art. 14(8)). The SRP report does not do this for you.

## How to use the templates

1. Copy the template into your incident folder before you start writing. Never edit the master.
2. Fill in what you know. "Unknown at this stage, assessment ongoing" is an acceptable answer in early stages. A late report is not.
3. Keep a timeline as you go (the runbook has one). The final report is mostly that timeline, cleaned up.
4. Before you submit, have a second person read it for anything that would help an attacker. Mark sensitivity in the form instead of leaving facts out.

## Important

This kit is practical guidance, not legal advice. The SRP launched in "initial operating capability" and ENISA is still changing it, so check field names against the live form. Where the law and this kit differ, the law wins: read Article 14 and Article 16 of Regulation (EU) 2024/2847 and your coordinating CSIRT's guidance.

Sources we checked when writing this kit:
- Regulation (EU) 2024/2847 (Cyber Resilience Act), Articles 3, 14, 16 — eur-lex.europa.eu
- ENISA CRA Single Reporting Platform and FAQ — portal.cra-srp.enisa.europa.eu
- BSI, CRA Single Reporting Platform — bsi.bund.de/dok/cra-srp-en

Questions, corrections, or a field that changed on the SRP? Write to hello@within24.app. We update the kit and email a new version.

---
Within24 watches the clocks for you: who is on duty, what is due, when, and a draft that is ready before the deadline. Early access at within24.app.
