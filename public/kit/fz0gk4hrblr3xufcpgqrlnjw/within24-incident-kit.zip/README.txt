Within24 Incident Kit - placeholder

The real kit (report templates, ENISA Single Reporting Platform readiness checklist,
first 60 minutes runbook) replaces this file before launch.
